﻿<%@ Page Title="" Language="vb" AutoEventWireup="false" MasterPageFile="~/MasterPage/Admin.Master" CodeBehind="EventPrize.aspx.vb" Inherits="EktaTrust.EventPrize" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
 






    <div class="clsBackImage wow fadeInDown animated">
        <div class="col-sm-12">
            
             <div class="col-sm-3">
               <%--<h2 style="margin-left: 31px;">Prize money for winners</h2>--%>
                 </div>
             <div class="col-sm-6">
             <center><h2>Run For Equality 2022</h2></center></div>
        </div>

        <div class="col-sm-12">
            <div class="col-sm-3">
               

                <%--<table class="table table-striped" style="box-shadow: 0px 1px 10px 2px lightgrey;">
                    <tr>
                        <td colspan="2">
                            <h6>21K (First Three Runners)</h6>
                        </td>
                    </tr>
                    <tr>
                        <td>First</td>
                        <td>Rs. 11,000</td>
                    </tr>
                    <tr>
                        <td>Second</td>
                        <td>Rs. 5,100</td>
                    </tr>
                    <tr>
                        <td>Third</td>
                        <td>Rs. 3,100</td>
                    </tr>

                    <tr>
                        <td colspan="2">
                            <h6>10K (First Three Runners)</h6>
                        </td>
                    </tr>
                    <tr>
                        <td>First</td>
                        <td>Rs. 5,100</td>
                    </tr>
                    <tr>
                        <td>Second</td>
                        <td>Rs. 3,100</td>
                    </tr>
                    <tr>
                        <td>Third</td>
                        <td>Rs. 2,100</td>
                    </tr>

                    <tr>
                        <td colspan="2">
                            <h6>5K (First Three Runners)</h6>
                        </td>
                    </tr>
                    <tr>
                        <td>First</td>
                        <td>Rs. 3,100</td>
                    </tr>
                    <tr>
                        <td>Second</td>
                        <td>Rs. 2,100</td>
                    </tr>
                    <tr>
                        <td>Third</td>
                        <td>Rs. 1,100</td>
                    </tr>

                </table>--%>
                <table class="table table-striped" style="box-shadow: 0px 1px 10px 2px lightgrey;">
                    <tr>
                        <td colspan="2">
                           <h6>Run for equality</h6>
                        </td>
                    </tr>
                     <tr style="box-shadow: 0px 1px 10px 2px lightgrey;" >
                      <td> 
                         <a href="#"><i class="fa fa-telegram"></i></a>                            
                      &nbsp; &nbsp;
                        <a href="#"><i class="fa fa-facebook"></i></a>                            
                         &nbsp; &nbsp;
                      <a href="#"><i class="fa fa-twitter"></i></a>                           
                        </td>
                        </tr>
                     <tr>
                        <td colspan="2" >
                            <h6>Run for Equality Schedule</h6><br />
                        </td>
                    </tr>
                    <tr>
                        <td> <video src="RunForEqualityGallery/RunForEqualityFMAds.mpeg" height="0" width="0" id="FMaudio" autoplay="autoplay"></video><br />
                        Date -14.04.2022<br />
                        Time-4:00AM &nbsp;- 21.09KM<br />
                      &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 5:00AM  - 10KM<br />
                           <%-- Run for Equality Schedule will be published shortly --%>
                       &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5:30AM  - 5KM <br />
                     Run Route - JLN Marg, Jaipur<br /><br />

                    Registration before - 31.03.2022 Rs-500<br /><br />
                     Registration after - 31.03.2022 Rs - 1000(Tshirt subject to availability)<br />
                    </td>
                       
                    </tr>
                   
                

                </table>
            </div>



          <div class="col-sm-6">
              <%--<img src="RunForEquality2018/IAS2.jpg" class="img-responsive" style="box-shadow: 0px 1px 10px 2px lightgrey; width:100%;" />--%>
    
           
              <%--<img src="Images/march1.jpg" style="box-shadow: 0px 1px 10px 2px lightgrey;height:750px; width:60%; " class="img-responsive" />--%>
            
             <%-- <img src="Images/images/RunForEquality2020.jpg" style="box-shadow: 0px 1px 10px 2px lightgrey;height:670px; width:102%; " class="img-responsive" />--%>
              
               <img src="Images/RunForEquality-2022.jpg" style="box-shadow: 0px 1px 10px 2px lightgrey; width:100%"  />
                <div class="row mt-5">
               <%-- <div class="col-lg-6" style="padding:0px 0px 0px 15px;">
                 <img src="Images/march3.jpg" style="box-shadow: 0px 1px 10px 2px lightgrey;height:400px; width:100%; " class="img-responsive" />
                  </div>
                  <div class="col-lg-6" style="padding:0px;">
                   <img src="Images/march2.jpg" style="box-shadow: 0px 1px 10px 2px lightgrey;height:400px; width:100%; " class="img-responsive" />
             </div>--%>
                   
                  <centre > <label  style="margin-top: 15px;
    margin-left: 10%;" >Sports Minister Shri Ashok Chandna inaugurating Run for Equality Registration 2022</label> </centre>
                      
              
              <%--<a href="https://www.onlinesbi.com/sbicollect/icollecthome.htm?corpID=922784">--%><%-- 
                  </a>--%>
                    <br />
                    <br />
                    
               <input type="checkbox" id="cbTermsAndCondition"  style="margin-left: 17px;" checked/><input type="button" id="btnTermsAndConditions" value="I Accept All Terms and Conditions" class="float-left" style="background-color:transparent;border:none;color:blue;text-decoration: underline; "  Text="I Accept Terms and Conditions" />
               
                <%--<a href="https://www.onlinesbi.com/sbicollect/icollecthome.htm?corpID=922784">--%>
                <%--<input type="button" style="margin-bottom:15px;margin-top:10px;font-size:larger;" id="EventRegistration" class="btn btn-success" value="Continue" onclick="test()" />--%>
     <%--   </a>--%>
                  <%--<a href="../EventRegistration.aspx" class="list-group-item active">--%>
                       <button onclick="termsAndCondition()" style="font-size:larger;margin-left: 10% ; margin-top: 0px;font-size:larger;" id="EventRegistration" class="btn btn-success" >Online Registration</button>
                  <%--</a>--%>    
               
          </div>
              </div>
            <div class="col-sm-3">


                <table class="table table-striped" style="box-shadow: 0px 1px 10px 2px lightgrey;">
                    <tr>
                        <td colspan="2">
                           <h6><center>Terms and Conditions</center></h6>
                        </td>
                    </tr>
                     <tr>
                      <td> 
                          <p>I agree that the fee paid is non-refundable and event category[5K, 10K, 21.09K] once filled cannot be modified.</p>
                          <p>I confirm that I am above 18 years old and I am physically fit to participate in this event.</p>
                          <p>I am aware that long distance running is extreme sport and can be injurious to body and health, hence I shall not hold the organisation or any of its member responsible for any injury/accident or any other mishap. Participation in this event is purely at my own risk.</p>
                          <p>I agree and understand that participating in this event includes contact with other participants, the effects of the weather including high heat or humidity, traffic and other condition of the road and all other risk associated with a public event.</p>
                          <p>I agree that the Ekta Navnirman Trust or its member cannot be held responsible in any way for loss or injury to myself, or any other party nor for any loss/damage of any of my valuables/belongings.</p>
                          <p>I agree to abide by the instructions provided by the organisers from time to time in the best interest of participants’ health and safety.</p>
                          <p>I agree to receive regular updates to the mobile number provided in the registration.</p>
                          <p>I agree that my name and media recording taken during your participation maybe used to publicise this event.</p>

  
                        </td>
                        
                   
                

                </table>
            </div>
            <br />
            <%--<img src="RunForEquality2018/IAS2.jpg" class="img-responsive" style="box-shadow: 0px 1px 10px 2px lightgrey; width:100%;" />--%>
    <%--        <img src="RunForEquality2018/IAS.jpg"  class="img-responsive" style="box-shadow: 0px 1px 10px 2px lightgrey; width:100%;" />--%>
            <br />

           <%--   <img src="RunForEquality2018/Ekta%20Banner.jpeg" class="img-responsive" style="box-shadow: 0px 1px 10px 2px lightgrey;  width:100%;" />--%>

            </div>

              
        <%--</div>--%>
     <%--<img src="RunForEquality2018/IAS2.jpg" class="img-responsive" style="box-shadow: 0px 1px 10px 2px lightgrey; width:100%;" />--%>
        <div class="row">
            
 
      <div class="col-sm-3"></div>
                
              <div class="col-sm-6">
          
              
                   </div>
             <div class="col-sm-3"></div>

        </div>

    </div>
   

     <video src="RunForEqualityGallery/RunForEqualityFMAds.mpeg" height="0" width="0" id="FMaudio" autoplay="autoplay"></video>

    <script type="text/javascript">
        $(document).ready(function () {
            
            var vid = document.getElementById("FMaudio");
            vid.volume = 0.2;
            
            

        });
</script> 
<script>
    function termsAndCondition() {
        debugger;
        var isChecked = $("#cbTermsAndCondition").is(":checked");
        if (isChecked)
        {
           // $(location).attr("href", "https://www.onlinesbi.com/sbicollect/icollecthome.htm?corpID=922784");
           //window.location.href = "https://www.onlinesbi.com/sbicollect/icollecthome.htm?corpID=922784";
           // window.location.href = 'https://www.onlinesbi.com/sbicollect/icollecthome.htm?corpID=922784';

            //var win = window.open('https://www.onlinesbi.com/sbicollect/icollecthome.htm?corpID=922784', '_blank');
            //win.focus();
            var win = window.open('../EventRegistration.aspx', '_blank');
            win.focus();
        }
        else {
            alert('Please Check Terms And Conditions!');
           
             }
}
</script>



<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
}

/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}
</style>
</head>
<body>



<!-- Trigger/Open The Modal -->
   


<!-- The Modal -->
<div id="Modal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
      <h3 align="center"><p align="left" style="color:black">Terms and Conditions</p></h3>
   <p>I agree that the fee paid is non-refundable and event category[5K, 10K, 21.09K] once filled cannot be modified.</p><br />
   <p>I confirm that I am above 18 years old and I am physically fit to participate in this event.</p><br />   
    <p>I am aware that long distance running is extreme sport and can be injurious to body and health, hence I shall not hold the organisation or any of its member responsible for any injury/accident or any other mishap. Participation in this event is purely at my own risk.</p><br />
      <p>I agree and understand that participating in this event includes contact with other participants, the effects of the weather including high heat or humidity, traffic and other condition of the road and all other risk associated with a public event.</p><br />
    <p>I agree that the Ekta Navnirman Trust or its member cannot be held responsible in any way for loss or injury to myself, or any other party nor for any loss/damage of any of my valuables/belongings.</p><br />
  <p>I agree to abide by the instructions provided by the organisers from time to time in the best interest of participants’ health and safety.</p><br />
  <p>I agree to receive regular updates to the mobile number provided in the registration.</p><br />
      <p>I agree that my name and media recording taken during your participation maybe used to publicise this event.</p><br />
  </div>

</div>

<script>
// Get the modal
var modal = document.getElementById("Modal");

// Get the button that opens the modal
var btn = document.getElementById("btnTermsAndConditions");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>

    </div>
</asp:Content>
